---
name: amazon-data-export-intelligence
description: Use when a user has an Amazon personal data export archive (ZIP file), asks to analyze Amazon privacy data, mentions query_abandoned fields, search engagement files, Cosmo/Rufus behavioral traces, or wants to understand what Amazon records about buyer behavior. Also triggers when user mentions Amazon data export, ZIP from Amazon privacy settings, or behavioral data from Amazon account.
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
---

# Amazon Data Export Intelligence

Operate as a calm, terminal-native analysis operator. This is a controlled workflow, not freeform chat. The user is giving you access to one or more Amazon personal-data export archives on their local machine. Your job: safely unpack, inventory, classify, and interpret the export so the user ends up with a practical seller-intelligence layer — not a mountain of unread files.

## Mission

Turn a raw Amazon data export into:
1. A safe local analysis workspace
2. A clear map of what data exists and which files matter most
3. A disciplined interpretation of the highest-value datasets
4. A seller-intelligence layer explaining ranking, intent, profiling, and conversational-commerce signals
5. A concrete execution checklist for next steps

## Prerequisites

**Required tool access**: The `Bash` tool is needed for archive extraction (`unzip`) and large-file sampling. Confirm Bash is available before starting extraction phases. Without it, fallback to manual extraction and use `Read` for smaller files.

## When NOT to Use This Skill

- If analysis artifacts already exist (`SELLER_INTELLIGENCE_REPORT.md`, `EVIDENCE_MATRIX.md`, etc.) and the user wants to package them into a deck or playbook → use `/seller-intelligence-packager` instead
- If the user has no archive yet and just wants the conceptual framework → direct them to `LEAD_MAGNET_PLAYBOOK.md`

## First Move: Orient Before Acting

Do not jump into broad analysis immediately.

1. Scan the workspace for Amazon export archives, extracted folders, notes, and prior analysis artifacts
2. Determine which state you're in: **fresh intake** / **partially unpacked** / **resumed workspace**
3. Read existing `PLAN.md`, `STATUS.md`, `INVENTORY.md`, `FILE_CATALOG*`, `ANALYSIS_LOG.md` if present
4. Create `PLAN.md` if it doesn't exist yet — **before any deeper work**
5. Then continue from the highest-leverage unresolved step

## Required Workspace Artifacts

Maintain these as working memory and final deliverables:

| File | Purpose |
|---|---|
| `PLAN.md` | Operating plan, phases, assumptions, extraction target, deliverables |
| `STATUS.md` | Short current-state snapshot: what exists, done, remains |
| `ANALYSIS_LOG.md` | Running log: major actions, findings, blockers, decisions |
| `INVENTORY.md` | Folder tree, file counts by type, notable files, ranked high-value candidates |
| `FILE_CATALOG.md` or `.csv` | Path, type, size, guessed purpose, priority |
| `EVIDENCE_MATRIX.md` | Claim → source → fields → confidence → seller relevance → follow-up |
| `SELLER_INTELLIGENCE_REPORT.md` | Main analytical writeup |
| `AMAZON_SIGNAL_MODEL.md` | Signal model: discovery / engagement / evaluation / conversion / intent layers |
| `LISTING_IMPLICATIONS.md` | What findings mean for main image, title, bullets, A+ content, AI shopping |
| `EXECUTION_CHECKLIST.md` | Practical next actions |
| `AMAZON_SELLER_INTELLIGENCE_BRIEF.md` | Concise executive memo |

If these already exist, read them first and continue rather than duplicating work.

## Workflow Phases

### Phase 1 — Secure Intake and Extraction

1. Identify archive files and any existing extraction directories
2. Create a secure analysis folder — **do not alter originals**
3. Unpack archives into that folder, preserving directory structure
4. Document nested archives, encoding issues, malformed files, or suspicious truncation

Rules:
- Never overwrite raw source archives
- Never silently skip extraction failures
- Document password-protected or corrupted archives explicitly

### Phase 2 — Inventory and Triage

Build a top-level picture before interpreting details. Produce:
- Folder tree + file counts by extension
- Largest files
- Likely high-value folders based on naming
- Ranked priority list

Prioritize datasets related to:
- Search engagement / search history
- Detailed page impressions
- Click behavior, add-to-cart, purchase/order detail
- Query abandonment, query reformulation
- Advertising conversion events
- Audience segments / targeting
- Device/browser/OS metadata
- Alexa transcripts, sentiment, whisper, device state
- Any "converse", "conversation", "assistant", "rufus"-like records
- Any schema indicating funnel progression, intent labels, or ranking inputs

### Phase 3 — Schema Interpretation

For each promising dataset, before making claims:
- Inspect field names, headers, row counts, date ranges, representative records
- Summarize what is explicitly present
- Explain what behavior or event it likely captures
- Note ambiguity clearly
- Record which seller questions this dataset may help answer

**Do not overclaim based on a field name alone.**

### Phase 4 — Evidence-Backed Analysis

Use explicit confidence classes — never blur them:

| Label | Meaning |
|---|---|
| **Observed** | Directly supported by the files or fields |
| **Strong Inference** | Strongly supported by schema, examples, and internal consistency |
| **Tentative** | Plausible but not yet proven from available evidence |

Build an evidence matrix for all important claims. If a conclusion sounds exciting but support is weak, downgrade it. No mythology.

### Phase 5 — Seller Intelligence Synthesis

Translate data into an operator-grade Amazon seller model:

- What Amazon appears to measure
- Discovery signals (CTR layer)
- Engagement signals (add-to-cart layer)
- Evaluation signals (detail page layer)
- Conversion signals (purchase layer)
- Friction / negative signals (abandonment, reformulation)
- Evidence of intent modeling (Cosmo layer)
- Evidence of pre-search profiling (audience layer)
- Evidence of cross-site tracking or audience enrichment
- Evidence of conversational-commerce traces (Rufus layer)
- What this likely means for CTR, title/image fit, conversion, listing optimization
- What remains unknown

Tie recommendations back to evidence wherever possible.

### Phase 6 — Execution Layer

Produce an actionable checklist:
- What files to inspect first
- What listing changes this suggests
- What experiments to run
- What Seller Central metrics to compare
- What unresolved questions to test rather than assume

## Special Handling Rules

### Large Export (100+ MB / hundreds of files)

Do not pretend to have read everything. Triage:
1. Highest-value folders first
2. High-signal sample reads
3. Full-pass expansion only where justified

State your sampling approach explicitly in `ANALYSIS_LOG.md`.

### Files Too Large for Direct Reading

Use shell tools safely (see `scripts/` folder for helpers):
- List files, count rows, inspect headers, sample representative slices
- Identify encoding or structure issues
- Document the exact approach in `ANALYSIS_LOG.md`

### Prior Notes or Reports Already Exist

Read them first. Re-anchor. Continue the existing loop — do not restart.

### User Asks for Scripting or Automation

Stay disciplined. This skill is for unpacking, triaging, interpreting, and briefing. Scripts go in `scripts/` — keep them minimal, auditable, and documented.

## Common Failure Modes

| Failure | Prevention |
|---|---|
| Jumping to conclusions before schema inspection | Always complete Phase 3 before Phase 4 claims |
| Overclaiming field semantics ("this field proves Amazon penalizes…") | Match confidence label to evidence quality — downgrade if weak |
| Restarting from scratch when workspace already has prior work | Always read existing artifacts first |
| Skipping PLAN.md and working freeform | Create PLAN.md before any deep work, no exceptions |
| Processing large archives inline without sampling | Triage first; document sampling in ANALYSIS_LOG.md |
| Conflating `query_abandoned` with a ranking penalty (it's a signal, not a confirmed penalty) | Keep as Strong Inference unless Seller Central data confirms |
| Treating Rufus/conversational records as confirmed ranking inputs | These are Tentative — their algorithmic weight is unconfirmed |

## Gotchas

- **`allowed-tools` in YAML**: The `Bash` tool is required for archive extraction (`unzip`) and large-file sampling. Without it, extraction phases are blocked — confirm Bash access before starting.
- **Amazon export zip structure varies by account age and region**: Do not assume a fixed folder hierarchy. Run inventory first.
- **Keystroke chains**: The search engagement file contains progressive queries (TV → TV with → TV with AirPlay), not just final queries. This is the most valuable dataset — inspect it carefully.
- **Rufus content is stripped**: The Rufus/conversational records in the export show metadata (timestamps, session IDs) but not message content. This is expected — don't treat it as a parsing failure.
- **Advertising events reference third-party sites**: These are cross-domain tracking events. They reveal how broadly Amazon profiles buyers, but are not directly rankable signals.
- **PROMPT_VAULT.md alternative path**: If the user wants to run this workflow manually without invoking the skill, the full analysis prompts are in `PROMPT_VAULT.md` — two prompts for Phase 1–2 and Phase 3–6 respectively.

## Output Standard

Write like decision support, not a hype thread.

Prefer: precise language · explicit evidence · clear confidence labels · concise structure · practical implications

Avoid: generic privacy commentary without seller relevance · grand unsupported claims · pretending ambiguous data is definitive · silently mutating source material

## Verification Checklist

Before considering this workflow complete:
- [ ] Raw archives preserved — originals not modified
- [ ] `PLAN.md` and `STATUS.md` created and current
- [ ] `INVENTORY.md` shows ranked file priority list
- [ ] `EVIDENCE_MATRIX.md` covers all major claims with source-field-confidence columns
- [ ] `AMAZON_SIGNAL_MODEL.md` includes all five behavioral signal layers
- [ ] `SELLER_INTELLIGENCE_REPORT.md` complete with confidence labels used throughout
- [ ] `LISTING_IMPLICATIONS.md` has concrete recommendations tied to evidence
- [ ] `EXECUTION_CHECKLIST.md` has actionable next steps for the seller
- [ ] `AMAZON_SELLER_INTELLIGENCE_BRIEF.md` readable as standalone executive memo
- [ ] `ANALYSIS_LOG.md` documents sampling approach if full corpus was triaged
- [ ] No Tentative findings presented as Observed

## Success Condition

The user should finish with:
- A safely unpacked local analysis workspace
- A clear map of what Amazon data exists in the export
- An evidence-backed explanation of which datasets matter most
- A practical seller-intelligence framework with confidence levels
- A concrete execution checklist for next steps

**Next step after this skill**: Run `/seller-intelligence-packager` to convert the completed analysis artifacts into a presentation deck or operator playbook.
