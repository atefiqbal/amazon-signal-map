# Skill Eval Cases

Realistic test scenarios that prove the skills are functional, correctly triggered,
and produce the right outputs. Run these to validate before deploying or after editing.

---

## How to Use This File

For each eval case:
1. Open a new Claude Code session in a test workspace
2. Use the stated setup conditions
3. Send the trigger message
4. Check the expected behavior checklist
5. Note any failures — they become skill improvement targets

---

## Skill 1: `amazon-data-export-intelligence`

### Eval A — Fresh Archive Intake (Core Flow)

**Setup**: A workspace with a file `amazon-export.zip` and no prior analysis artifacts

**Trigger message**:
> "I just downloaded my Amazon data export. The zip file is at ~/Desktop/amazon-export.zip. Let's analyze it."

**Expected behavior**:
- [ ] Skill invoked (not generic freeform response)
- [ ] Agent scans workspace first before extracting
- [ ] Creates `PLAN.md` before any extraction
- [ ] Extracts archive to a secure folder without renaming/moving original
- [ ] Produces `INVENTORY.md` with folder tree, file counts, high-value candidates ranked
- [ ] Inspects search engagement files first (not alphabetically)
- [ ] Uses confidence labels: Observed / Strong Inference / Tentative
- [ ] Does NOT claim `query_abandoned` definitively causes ranking penalty (Tentative)
- [ ] Produces `EVIDENCE_MATRIX.md` with source-field-confidence columns
- [ ] Produces `EXECUTION_CHECKLIST.md` with concrete seller actions
- [ ] Produces `AMAZON_SELLER_INTELLIGENCE_BRIEF.md` as final memo
- [ ] Mentions `/seller-intelligence-packager` as next step

**Failure modes to watch for**:
- Agent jumps straight to extraction without creating PLAN.md
- Agent claims Rufus data is confirmed ranking input (should be Tentative)
- Agent produces only 1–2 artifacts instead of the full set
- Agent restarts if asked to re-run without reading existing artifacts first

---

### Eval B — Resumed Workspace (Continuity Test)

**Setup**: A workspace that already has `PLAN.md`, `STATUS.md`, `INVENTORY.md`, and `SELLER_INTELLIGENCE_REPORT.md` (simulate prior analysis)

**Trigger message**:
> "Let's continue the analysis."

**Expected behavior**:
- [ ] Agent reads existing artifacts first (doesn't restart from scratch)
- [ ] Creates or updates `STATUS.md` showing what exists vs. what remains
- [ ] Continues from where work left off
- [ ] Does NOT re-extract or re-inventory if already done
- [ ] Identifies the highest-leverage unresolved step and does that

**Failure modes to watch for**:
- Agent ignores existing artifacts and restarts
- Agent creates duplicate/conflicting PLAN.md

---

### Eval C — Large Export Triage (Scale Test)

**Setup**: A workspace description of a 300+ file, 200MB export

**Trigger message**:
> "I've got a huge export — 300+ files. Let's start analyzing it."

**Expected behavior**:
- [ ] Agent explicitly states it will triage rather than read everything
- [ ] Creates ranked priority list of high-value folders
- [ ] States sampling methodology clearly in ANALYSIS_LOG.md
- [ ] Focuses on Search engagement, Advertising, Audience files first
- [ ] Does NOT claim to have "analyzed all 300 files"

**Failure modes to watch for**:
- Agent claims comprehensive analysis without sampling disclosure
- Agent processes files alphabetically instead of by seller relevance

---

### Eval D — Confidence Discipline (Anti-Overclaim Test)

**Setup**: Analysis in progress, agent finds `query_abandoned` field

**Trigger message**:
> "What does the query_abandoned field mean for ranking? Does abandonment directly cause a ranking drop?"

**Expected behavior**:
- [ ] Agent correctly labels this as Strong Inference (not Observed)
- [ ] Explains: Amazon records abandonment, likely uses it as a signal, but direct ranking causation is not confirmed from the export alone
- [ ] Suggests Seller Central A/B test to validate
- [ ] Does NOT say "query abandonment causes ranking drops" as fact

**Failure modes to watch for**:
- Agent presents inference as confirmed fact
- Agent hedges so much it provides no actionable insight

---

## Skill 2: `seller-intelligence-packager`

### Eval E — Playbook Mode Trigger

**Setup**: Workspace contains `SELLER_INTELLIGENCE_REPORT.md`, `EVIDENCE_MATRIX.md`, `AMAZON_SIGNAL_MODEL.md`, `LISTING_IMPLICATIONS.md`, `EXECUTION_CHECKLIST.md`

**Trigger message**:
> "Create a seller playbook from the analysis."

**Expected behavior**:
- [ ] Skill invoked (not generic response)
- [ ] Agent reads ALL source files before writing
- [ ] Produces `SELLER_PLAYBOOK.md` with all 12 sections
- [ ] Produces `SELLER_PLAYBOOK.html` with premium visual formatting
- [ ] Each section ends with decision rules or checklist
- [ ] Confidence labels preserved (Tentative items labeled as such)
- [ ] Rufus layer labeled Tentative throughout
- [ ] Produces `ONE_PAGE_ACTION_BRIEF.md` if source material is rich enough
- [ ] Playbook reads like operator manual, not blog post

**Failure modes to watch for**:
- Agent reads only 1–2 source files instead of all available
- Agent promotes Tentative findings to confirmed
- Agent produces only `.md` without `.html` version
- Playbook has no decision rules or checklists

---

### Eval F — Presentation Mode Trigger

**Setup**: Same workspace as Eval E

**Trigger message**:
> "Build me a deck I can present to a client."

**Expected behavior**:
- [ ] Skill invoked in Presentation Mode
- [ ] Produces `PRESENTATION_OUTLINE.md` with all 14 slides structured
- [ ] Produces `PRESENTATION_BRIEFING.html` in premium visual format
- [ ] Each slide has: title, objective, 3–6 points, suggested visual, speaker note
- [ ] Deck flows: context → evidence → interpretation → action
- [ ] Slide 4 ("What appears confirmed") contains only Observed findings
- [ ] Slide 5 ("What appears likely") contains only Strong Inference findings
- [ ] Open questions slide present (slide 13)

**Failure modes to watch for**:
- Agent skips HTML output
- Agent mixes confidence levels across slides 4 and 5
- Agent presents full 224-line analysis as slides without compression
- Deck has no logical flow (just concatenated findings)

---

### Eval G — Missing Source Files (Graceful Degradation)

**Setup**: Workspace has only `SELLER_INTELLIGENCE_REPORT.md` — missing EVIDENCE_MATRIX.md, SIGNAL_MODEL, etc.

**Trigger message**:
> "Package this into a playbook."

**Expected behavior**:
- [ ] Agent explicitly states which source files are missing
- [ ] Proceeds with what exists
- [ ] Clearly marks sections as "limited due to missing evidence matrix"
- [ ] Does NOT fabricate evidence matrix rows
- [ ] Produces a useful (if limited) output

**Failure modes to watch for**:
- Agent halts entirely instead of working with available material
- Agent silently produces output as if all source files existed

---

### Eval H — Mode Ambiguity

**Setup**: Full workspace with all source files

**Trigger message**:
> "Give me the output from the analysis."

**Expected behavior**:
- [ ] Agent asks or infers mode (deck vs. playbook)
- [ ] OR produces lightweight versions of both, labeled, and asks which to expand
- [ ] Does NOT just re-output the SELLER_INTELLIGENCE_REPORT.md

**Failure modes to watch for**:
- Agent defaults to one mode without surfacing the choice
- Agent produces raw re-summary instead of packaged artifact

---

## Regression Check After Skill Edits

Run these quick checks after any SKILL.md edit:

| Check | Pass condition |
|---|---|
| Description starts with "Use when..." | Verify first two words of description field |
| Description ≤ 1024 chars total YAML | `wc -c < SKILL.md` should account for this |
| No workflow summary in description | Description describes triggers, not process |
| Common failure modes documented | Section exists in skill body |
| Gotchas section exists | Section exists in skill body |
| HTML output mentioned for packager | Check PRESENTATION_BRIEFING.html, SELLER_PLAYBOOK.html |
| Cross-skill references intact | `amazon-data-export-intelligence` references packager; packager references export-intelligence |
