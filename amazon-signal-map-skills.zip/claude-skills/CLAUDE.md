# CLAUDE.md

## Purpose
This workspace is used to unpack, inventory, and analyze Amazon personal-data export archives in a safe, local, non-destructive way so the resulting files can be interpreted for seller-relevant intelligence.

The goal is not generic privacy commentary. The goal is to identify what the export appears to contain, which datasets matter most, and what the data may imply for Amazon search, ranking, shopper-intent modeling, audience profiling, listing optimization, and conversational commerce.

## Default working style
- Be calm, methodical, and explicit.
- Prefer small, reviewable steps.
- Never mutate or delete raw source archives.
- Externalize memory into markdown artifacts as work progresses.
- Distinguish direct observation from inference.
- If something is ambiguous, say so plainly.
- If an action could have meaningful blast radius, pause and explain first.

## Primary workflow
When working in this repo/workspace:

1. Read existing context files first:
   - `PLAN.md`
   - `STATUS.md`
   - `ANALYSIS_LOG.md`
   - `INVENTORY.md`
   - `FILE_CATALOG.*`
   - `EVIDENCE_MATRIX.md`
   - any existing report files

2. If these files do not exist, create `PLAN.md` first before deep work.

3. Then proceed through:
   - secure intake / extraction
   - inventory / triage
   - schema interpretation
   - evidence-backed analysis
   - seller-intelligence synthesis
   - execution checklist

## Skills available in this workspace

Two Claude Code skills handle this workflow:

| Skill | Trigger | Use when |
|---|---|---|
| `/amazon-data-export-intelligence` | Raw export archive exists | Unpack, inventory, and analyze → seller intelligence artifacts |
| `/seller-intelligence-packager` | Analysis artifacts exist | Package findings into presentation deck or operator playbook |

If skills are not installed: use the manual prompts in `../PROMPT_VAULT.md` instead.

## Required output artifacts
Maintain these as the working memory and deliverable set:

- `PLAN.md`
- `STATUS.md`
- `ANALYSIS_LOG.md`
- `INVENTORY.md`
- `FILE_CATALOG.md` or `FILE_CATALOG.csv`
- `EVIDENCE_MATRIX.md`
- `AMAZON_SIGNAL_MODEL.md`
- `SELLER_INTELLIGENCE_REPORT.md`
- `LISTING_IMPLICATIONS.md`
- `EXECUTION_CHECKLIST.md`
- `AMAZON_SELLER_INTELLIGENCE_BRIEF.md`

Create them incrementally as needed. Do not regenerate unnecessarily if they already exist and are still valid.

## Analysis priorities
Prioritize anything related to:

- search engagement
- search history
- click behavior
- detailed page impressions
- add-to-cart behavior
- purchase detail
- query abandonment
- query reformulation
- advertising conversion events
- audience segments / targeting
- device / browser / OS metadata
- Alexa transcripts, sentiment, whisper detection, device-state logs
- any "converse", "conversation", "assistant", or "rufus"-like records
- any schemas suggesting funnel progression, intent modeling, or ranking inputs

## Confidence discipline
Use these confidence labels in analytical writing:

- **Observed** — directly supported by source files, field names, or representative records
- **Strong Inference** — strongly supported by schema, examples, and internal consistency
- **Tentative** — plausible but not proven from available evidence

Do not blur these categories.

## Guardrails
- Never alter raw export files.
- Never silently skip extraction or parsing failures.
- Never claim a field means more than the evidence supports.
- Never drift into broad privacy editorializing unless it directly informs seller relevance.
- Never upload, sync, or transmit local data unless explicitly instructed.
- If processing is partial due to size, sample methodically and document the sampling approach.

## Large-data behavior
If the export is large:
- triage first
- rank folders/files by likely value
- inspect representative samples
- document the method in `ANALYSIS_LOG.md`
- expand deeper only where justified

Do not pretend the full corpus was exhaustively interpreted if it was triaged.

## Scripting behavior
If local scripts are useful:
- keep them minimal and auditable
- store them in `scripts/`
- document what they do
- never make them destructive
- prefer scripts that inspect, summarize, count, or normalize derived outputs rather than mutate source data

Two pre-built inspection scripts are in `scripts/`:
- `scripts/inspect-archive.sh` — safe archive/directory inspection (no extraction of originals)
- `scripts/sample-csv.sh` — schema and row sampling for large CSV/JSON files

## What "good" looks like
A strong result from this workspace gives the user:

1. a safely unpacked analysis environment
2. a clear map of what data exists
3. a ranked view of which files matter most
4. an evidence-backed interpretation of important datasets
5. a practical explanation of what the findings may imply for Amazon sellers
6. a checklist of what to inspect, test, or change next

## Tone
Write like an operator and analyst, not a hype marketer.
Be precise, readable, and practical.
Decision support beats drama.
