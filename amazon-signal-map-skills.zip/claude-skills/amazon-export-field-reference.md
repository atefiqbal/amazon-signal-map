# Amazon Export Field Reference

Known field names, file types, and their seller-relevance interpretation.
Derived from direct schema inspection of a real Amazon data export.
Use this as a reference during Phase 3 (schema interpretation) to accelerate analysis.

---

## Search Engagement Fields

These appear in the search/search-engagement dataset — the highest-value file in the export.

| Field Name | Type | What It Captures | Seller Relevance |
|---|---|---|---|
| `query` | string | The final search term submitted | Keywords the buyer used |
| `keystroke_chain` or progressive queries | array/string | Every intermediate query typed before final submission | How buyers think before searching — reveals intent evolution |
| `number_of_clicked_items` | integer | How many listings were clicked for this session | CTR proxy at session level |
| `number_of_items_added_to_cart` | integer | How many items were added to cart in this session | Add-to-cart rate signal |
| `purchase_any_item` | boolean | Whether any purchase occurred in this session | Conversion signal (terminal) |
| `query_abandoned` | boolean | Whether the search session ended with no click or purchase | **Critical negative signal** — buyer saw results and left unsatisfied |
| `query_reformulated` | boolean | Whether the buyer changed their search | Another negative signal — your results didn't satisfy intent |
| `session_id` | string | Unique identifier per search session | Used to group related queries |
| `timestamp` or `date` | datetime | When the session occurred | Time-series analysis, seasonality |
| `search_refinement` | various | Any filter/refinement actions applied | Reveals buyers narrowing intent |

**Key insight**: `query_abandoned` and `query_reformulated` are the signals most sellers don't know about. They indicate your listing appeared in results but did not satisfy buyer intent.

---

## Advertising / Conversion Event Fields

Appear in the Advertising or Conversion Events dataset.

| Field Name | Type | What It Captures | Seller Relevance |
|---|---|---|---|
| `event_type` | string | Type of ad interaction logged | Reveals Amazon's cross-site tracking scope |
| `site_domain` | string | Domain where the event was logged | Amazon tracks behavior on non-Amazon sites |
| `device_type` | string | Device category (desktop, mobile, etc.) | Cross-device profiling |
| `browser` | string | Browser name and version | Browser-level fingerprinting |
| `os` | string | Operating system | Device fingerprint detail |
| `timestamp` | datetime | When the event occurred | Timing of cross-site tracking |
| `advertiser_id` | string | Which Amazon advertiser triggered the pixel | Shows advertising ecosystem scope |

**Key insight**: These events show Amazon tracking buyer behavior across third-party websites (Nike, food delivery apps, voter registration sites). This feeds pre-search audience classification.

---

## Audience / Targeting Fields

Appear in the advertising audience or targeting dataset.

| Field Name | Type | What It Captures | Seller Relevance |
|---|---|---|---|
| `segment_name` or `audience_name` | string | Behavioral classification bucket | How Amazon categorized this buyer before they searched |
| `category` | string | High-level interest/intent category | Pre-search intent inference |
| `advertiser_count` | integer | How many advertisers have this buyer in audience | Demand signal for this audience segment |
| `date_added` | date | When buyer entered this segment | Recency of classification |

**Key insight**: Amazon pre-classifies buyers into audiences before any search query is typed. Sellers whose listings align with these pre-existing classifications get favorable placement.

---

## Detailed Page Impression Fields

Appear in impression or page-view datasets.

| Field Name | Type | What It Captures | Seller Relevance |
|---|---|---|---|
| `asin` | string | Product identifier shown | Which listings got impressions |
| `impression_count` | integer | Number of times product was shown | Volume of search appearances |
| `click_count` | integer | Number of times product was clicked | CTR denominator/numerator |
| `position` | integer | Rank position in search results | Position vs. CTR correlation |
| `query` | string | Search query that triggered the impression | Query-level impression attribution |

---

## Alexa / Voice Data Fields

Appear in Alexa transcripts or device-state logs (if the account uses Alexa).

| Field Name | Type | What It Captures | Seller Relevance |
|---|---|---|---|
| `utterance` | string | What was said to Alexa | Voice search query patterns |
| `transcript` | string | Full voice interaction transcript | Conversational query shapes |
| `device_state` | object | Alexa device status metadata | Device-level behavior |
| `sentiment` | string | Positive/neutral/negative classification | Emotional context of voice queries |
| `whisper_mode` | boolean | Whether whisper detection was active | Privacy behavior signal |

**Key insight**: Voice queries tend to be more conversational and problem-shaped than text queries ("Alexa, find me a protein powder that doesn't taste chalky"). These patterns anticipate Rufus-style queries.

---

## Conversational / Rufus-Adjacent Records

Appear as "Converse" or "Conversation" data in the export.

| Field Name | Type | What It Captures | Seller Relevance |
|---|---|---|---|
| `session_id` | string | Conversation session identifier | Groups a full conversational shopping session |
| `timestamp` | datetime | When messages were exchanged | Session timing |
| `message_content` | — | **Typically missing / stripped** | Amazon does not return conversation content in the export |
| `turn_count` | integer | Number of back-and-forth turns | Length of AI shopping conversation |

**Key insight**: Amazon logs that Rufus conversations happened, including timestamps and turn counts, but strips the actual content from the export. This is the only category where content is missing. The absence itself is significant — Amazon considers this data especially sensitive.

---

## Confidence Notes for Field Interpretation

| Confidence Level | When to Apply |
|---|---|
| **Observed** | Field name and values directly visible in source file with clear semantics |
| **Strong Inference** | Field name aligns with known Amazon systems; schema context supports interpretation |
| **Tentative** | Field exists but purpose is ambiguous; interpretation requires external context |

**Never upgrade a Tentative interpretation to Observed without seeing clear field values.**

---

## Known File/Folder Names (High-Value)

These folder or file name patterns indicate high-value datasets based on observed export structures:

```
Search/
  Search.SearchEngagement.csv        ← PRIMARY — five behavioral signals
  Search.History.csv                 ← Query text history

Advertising/
  Advertising.ConversionEvents.json  ← Cross-site tracking events
  Advertising.AudienceSegments.json  ← How Amazon classified the buyer

DetailPageViews/
  DetailPageViews.Impressions.csv    ← Product page impression data

Alexa/
  Alexa.VoiceHistory.csv             ← Voice query transcripts
  Alexa.SmartHome.json               ← Device state data

Converse/ or Conversation/
  (Any files here)                   ← Rufus / AI shopping traces
                                       (content typically stripped)
```

---

*This reference is derived from one export sample (14-year account, 369 files, 150,000+ records).
Amazon's export structure varies by account age, region, and services used.*
*Update this file when new field names are discovered during analysis.*
