---
name: seller-intelligence-packager
description: Use when the Amazon data export analysis is already complete and the workspace contains SELLER_INTELLIGENCE_REPORT.md, EVIDENCE_MATRIX.md, AMAZON_SIGNAL_MODEL.md, or similar artifacts. Triggers when the user asks for a "deck", "slides", "presentation", "briefing", "playbook", "manual", "SOP", or "operator guide" based on analysis that already exists. Requires prior completion of amazon-data-export-intelligence workflow.
allowed-tools:
  - Read
  - Write
  - Edit
---

# Seller Intelligence Packager

Operate as a packaging and synthesis agent, not a discovery agent. This skill assumes the workspace already contains completed (or substantially complete) Amazon seller-intelligence outputs: reports, evidence matrices, briefs, execution checklists. Your job is to transform those outputs into one of two artifact types — or both.

## When NOT to Use This Skill

- If the analysis archive has not yet been processed → run `/amazon-data-export-intelligence` first
- If `SELLER_INTELLIGENCE_REPORT.md` and `EVIDENCE_MATRIX.md` are both missing → state this and prompt the user to run the analysis phase first
- If the user wants raw data interpretation → that is the export-intelligence skill's job

## Source Dependency Check

Before packaging, confirm which source files exist. Read all that are present:

| File | Role in packaging |
|---|---|
| `AMAZON_SELLER_INTELLIGENCE_BRIEF.md` | High priority — executive summary layer |
| `SELLER_INTELLIGENCE_REPORT.md` | High priority — main analytical layer |
| `EVIDENCE_MATRIX.md` | High priority — confidence calibration |
| `AMAZON_SIGNAL_MODEL.md` | High priority — signal framework |
| `LISTING_IMPLICATIONS.md` | High priority — actionable layer |
| `EXECUTION_CHECKLIST.md` | High priority — operator actions |
| `OPEN_QUESTIONS_AND_TESTS.md` | Supporting — unresolved items |
| `STATUS.md` | Supporting — current workspace state |
| `PLAN.md` | Supporting — analytical scope |

If some are missing: proceed with what exists and state the limitations explicitly in the output. Do not fabricate content to fill gaps.

## Mode Selection

**If the user specifies a mode, use it.**

If not specified, infer from language:
- "deck", "slides", "presentation", "briefing", "workshop" → **Presentation Mode**
- "playbook", "manual", "SOP", "operator guide", "field guide" → **Playbook Mode**

If still unclear: create both in lightweight form, labeled separately, and let the user choose which to expand.

---

## Presentation Mode

Creates:
- `PRESENTATION_OUTLINE.md`
- optionally `SPEAKER_NOTES.md`
- `PRESENTATION_BRIEFING.html` — premium HTML version, client-ready visual polish (use workspace `frontend-design` conventions if available)

### Deck Structure

| # | Slide | Objective |
|---|---|---|
| 1 | Title | Orient the audience |
| 2 | Why this matters | Stakes and relevance |
| 3 | What data was analyzed | Scope and credibility |
| 4 | What appears confirmed | Observed-level findings only |
| 5 | What appears likely | Strong-inference findings |
| 6 | What Amazon may be measuring | Signal model summary |
| 7 | Search / ranking signal model | The five-signal framework |
| 8 | Intent-modeling implications | Cosmo / search-to-purchase pairs |
| 9 | Audience / profiling implications | Pre-search classification layer |
| 10 | Conversational-commerce implications | Rufus and AI shopping trajectory |
| 11 | Listing optimization implications | What to change and why |
| 12 | What sellers should do now | Priority actions |
| 13 | Open questions / tests | What still needs validation |
| 14 | Appendix / evidence highlights | Supporting evidence |

**For each slide include:**
- Slide title
- Slide objective (1 sentence)
- 3–6 core points
- Suggested table/chart/visual if relevant
- Concise speaker note (2–4 sentences)

**Deck logic must be progressive:** context → evidence → interpretation → action

---

## Playbook Mode

Creates:
- `SELLER_PLAYBOOK.md`
- `SELLER_PLAYBOOK.html` — premium HTML version with operator-manual visual logic: tables, callouts, checklists (use workspace `frontend-design` conventions if available)

### Playbook Structure

1. **Executive summary** — What this is, what it found, what matters most
2. **What this analysis is and is not** — Scope, limitations, confidence levels
3. **Amazon signal model** — The five behavioral signals with practical explanations
4. **What sellers should optimize for** — Priority surface areas
5. **Main image / CTR doctrine** — Discovery layer principles
6. **Title / intent-fit doctrine** — Writing for intent, not catalog
7. **Bullets / copy / objection handling** — Spec → benefit → felt outcome formula
8. **Negative-signal avoidance** — What generates bad evidence in Amazon's system
9. **Conversational-commerce readiness** — Rufus/AI optimization principles
10. **Weekly operating rhythm** — Recurring review loops
11. **Testing roadmap** — What to A/B test and why
12. **Open questions and validation plan** — What is still tentative, how to confirm

### Playbook Must Include

- Decision rules ("if this, then that" guidance)
- Recurring review loops (weekly, monthly)
- Implementation phases (quick wins / 30-day / 90-day)
- Checklists at section ends
- A short glossary if useful

**Write it like an operator manual, not a blog post.**

---

## Optional Enhancement

If source materials support it, also create:

### `ONE_PAGE_ACTION_BRIEF.md` + `ONE_PAGE_ACTION_BRIEF.html`

A compressed artifact for a busy operator:
- What matters (top 3 findings)
- What to do first (priority action with urgency reason)
- What to test next (2–3 specific experiments)
- What not to overclaim (1–2 things still tentative)

Keep the HTML version to a single printable page or short scroll. No filler.

---

## Packaging Discipline

| Rule | Why |
|---|---|
| Compress repetition | Source files often overlap — consolidate, don't copy-paste |
| Preserve strongest evidence | Lead with what's supported, not what's exciting |
| Keep recommendations concrete | "Rewrite title to lead with buyer-relevant promise" beats "optimize title" |
| Group related insights into clean frameworks | Signal layers, funnel stages, optimization phases |
| Call out confirmed vs. inferred | Never flatten confidence labels for presentation polish |
| Avoid vague filler | Never use "data-driven" unless paired with a specific action |

---

## Common Failure Modes

| Failure | Prevention |
|---|---|
| Starting packaging without reading source files | Always read all available artifacts first — reanchor before packaging |
| Inflating confidence for presentation polish | "Tentative" in the evidence matrix stays tentative in the deck |
| Creating a generic Amazon best-practices output | Every claim must trace to a source file or evidence matrix row |
| Missing the HTML output | Always produce `.html` alongside `.md` for client-ready artifacts |
| Playbook reads like a blog post | Each section ends with a decision rule, checklist, or if/then guidance |
| Mode ambiguity causing incomplete output | If unclear, produce both lightweight versions and let the user choose |

## Gotchas

- **Confidence flatness**: The evidence matrix has three levels. The packaged output must preserve this. Do not present Tentative findings with the same weight as Observed ones.
- **HTML output is not optional for client-ready delivery**: The `.html` versions are the actual deliverables for presentation or handoff. The `.md` versions are the drafts.
- **`allowed-tools` excludes Bash**: This skill reads existing artifacts and writes new ones. It does not run shell commands. If you need to re-inspect raw files, switch back to `amazon-data-export-intelligence`.
- **Do not re-run the forensic analysis**: If source files have gaps, document the gap and state what conclusions are limited. Do not invent findings to fill the outline.
- **The Rufus layer is Tentative throughout**: Do not promote it to confirmed without explicit seller-side validation.

## Verification Checklist

Before marking output complete:
- [ ] All available source files were read and used
- [ ] Confidence labels preserved from evidence matrix (not flattened)
- [ ] Every key recommendation traces to a source finding
- [ ] `.html` version produced alongside `.md`
- [ ] One-page brief produced if source material was rich enough
- [ ] Open questions appear explicitly in the output — not buried

## Success Condition

The final output lets the user either:
1. Present the findings cleanly to a team, client, or executive audience, OR
2. Run the findings as an actual Amazon seller operating playbook

Both outputs should be readable by someone who has not seen the raw analysis files.
