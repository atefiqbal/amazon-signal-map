#!/bin/bash
# sample-csv.sh
# Usage: ./sample-csv.sh <path-to-csv-or-json> [num-rows]
# Purpose: Safely inspect schema and sample rows from a large CSV or JSON file.
#          Useful for large Amazon export files that cannot be read inline.
#          Never modifies source files.

set -e

FILE="${1:-}"
ROWS="${2:-5}"

if [ -z "$FILE" ]; then
  echo "Usage: $0 <path-to-file> [num-rows]"
  echo "  Default: 5 sample rows"
  echo "  Example: $0 ~/Desktop/amazon-export/search-engagement.csv 10"
  echo "  Example: $0 ~/Desktop/amazon-export/Advertising.ConversionEvents.json 5"
  exit 1
fi

if [ ! -f "$FILE" ]; then
  echo "ERROR: File not found: $FILE"
  exit 1
fi

EXTENSION="${FILE##*.}"
EXTENSION_LOWER=$(echo "$EXTENSION" | tr '[:upper:]' '[:lower:]')

echo "====================================================="
echo " AMAZON EXPORT FILE SAMPLER"
echo " File: $FILE"
echo " Extension: .$EXTENSION_LOWER"
echo "====================================================="
echo ""

echo "--- File size ---"
du -sh "$FILE"
echo ""

echo "--- Line count ---"
wc -l < "$FILE"
echo ""

# --- CSV branch ---
if [[ "$EXTENSION_LOWER" == "csv" ]]; then
  echo "--- Column headers ---"
  head -1 "$FILE"
  echo ""
  echo "--- Column count ---"
  head -1 "$FILE" | tr ',' '\n' | wc -l
  echo ""
  echo "--- Column names (one per line) ---"
  head -1 "$FILE" | tr ',' '\n' | nl
  echo ""
  echo "--- Sample rows (first $ROWS data rows) ---"
  head -$((ROWS + 1)) "$FILE" | tail -$ROWS
  echo ""
  echo "--- Last $ROWS rows ---"
  tail -$ROWS "$FILE"

# --- JSON branch ---
elif [[ "$EXTENSION_LOWER" == "json" ]]; then
  echo "--- Top-level structure (first 50 chars per key) ---"
  python3 -c "
import json, sys
with open('$FILE', 'r', encoding='utf-8', errors='replace') as f:
    try:
        data = json.load(f)
        if isinstance(data, list):
            print(f'Type: Array — {len(data)} items')
            if len(data) > 0:
                print('First item keys:', list(data[0].keys()) if isinstance(data[0], dict) else type(data[0]))
                print()
                print('=== Sample records ===')
                for i, item in enumerate(data[:$ROWS]):
                    print(f'--- Record {i+1} ---')
                    print(json.dumps(item, indent=2)[:800])
                    print()
        elif isinstance(data, dict):
            print('Type: Object')
            print('Top-level keys:', list(data.keys()))
    except json.JSONDecodeError as e:
        print(f'JSON parse error: {e}')
        print('Showing raw first 500 chars:')
        f.seek(0)
        print(f.read(500))
" 2>/dev/null || {
    echo "[Python3 not available or parse error — showing raw head]"
    head -30 "$FILE"
  }

# --- JSONL / NDJSON branch ---
elif [[ "$EXTENSION_LOWER" == "jsonl" ]] || [[ "$EXTENSION_LOWER" == "ndjson" ]]; then
  echo "--- Sample records (first $ROWS lines) ---"
  head -$ROWS "$FILE" | python3 -c "
import sys, json
for i, line in enumerate(sys.stdin):
    line = line.strip()
    if line:
        try:
            obj = json.loads(line)
            print(f'--- Record {i+1} ---')
            print(json.dumps(obj, indent=2)[:600])
            print()
        except:
            print(f'--- Line {i+1} (raw) ---')
            print(line[:300])
            print()
" 2>/dev/null || head -$ROWS "$FILE"

# --- TSV branch ---
elif [[ "$EXTENSION_LOWER" == "tsv" ]]; then
  echo "--- Column headers ---"
  head -1 "$FILE"
  echo ""
  echo "--- Column names (one per line) ---"
  head -1 "$FILE" | tr '\t' '\n' | nl
  echo ""
  echo "--- Sample rows (first $ROWS data rows) ---"
  head -$((ROWS + 1)) "$FILE" | tail -$ROWS

# --- Generic text fallback ---
else
  echo "--- First 30 lines ---"
  head -30 "$FILE"
fi

echo ""
echo "====================================================="
echo " Sampling complete. File was not modified."
echo "====================================================="
