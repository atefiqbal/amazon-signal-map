#!/bin/bash
# inspect-archive.sh
# Usage: ./inspect-archive.sh <path-to-zip-or-folder>
# Purpose: Safe inspection of an Amazon export archive — shows structure,
#          counts files by type, and flags likely high-value folders.
#          Never extracts or modifies source files.

set -e

TARGET="${1:-}"

if [ -z "$TARGET" ]; then
  echo "Usage: $0 <path-to-zip-or-folder>"
  echo "  Example: $0 ~/Desktop/amazon-data.zip"
  echo "  Example: $0 ~/Desktop/amazon-export-extracted/"
  exit 1
fi

echo "====================================================="
echo " AMAZON EXPORT INSPECTOR"
echo " Target: $TARGET"
echo "====================================================="
echo ""

# --- ZIP file branch ---
if [[ "$TARGET" == *.zip ]]; then
  echo "[MODE] ZIP archive — listing contents without extracting"
  echo ""
  echo "--- File count by extension ---"
  unzip -l "$TARGET" 2>/dev/null | awk '{print $NF}' | grep '\.' | sed 's/.*\.//' | tr '[:upper:]' '[:lower:]' | sort | uniq -c | sort -rn | head -20
  echo ""
  echo "--- Top-level folders ---"
  unzip -l "$TARGET" 2>/dev/null | awk '{print $NF}' | grep '/' | awk -F'/' '{print $1}' | sort -u | head -30
  echo ""
  echo "--- Largest files ---"
  unzip -l "$TARGET" 2>/dev/null | sort -rn | head -15
  echo ""
  echo "--- Likely high-value files (keyword scan) ---"
  unzip -l "$TARGET" 2>/dev/null | awk '{print $NF}' | grep -iE "search|engagement|impression|click|cart|purchase|order|abandon|query|advert|audience|targeting|segment|alexa|converse|rufus|assistant|voice|whisper|device|browser" | head -30

# --- Directory branch ---
elif [ -d "$TARGET" ]; then
  echo "[MODE] Extracted directory — scanning structure"
  echo ""
  echo "--- Folder tree (top 3 levels) ---"
  find "$TARGET" -maxdepth 3 -type d | sort | head -50
  echo ""
  echo "--- File count by extension ---"
  find "$TARGET" -type f | sed 's/.*\.//' | tr '[:upper:]' '[:lower:]' | sort | uniq -c | sort -rn | head -20
  echo ""
  echo "--- Total file count ---"
  find "$TARGET" -type f | wc -l
  echo ""
  echo "--- Largest files ---"
  find "$TARGET" -type f -exec du -sh {} \; 2>/dev/null | sort -rh | head -15
  echo ""
  echo "--- Likely high-value files (keyword scan) ---"
  find "$TARGET" -type f | grep -iE "search|engagement|impression|click|cart|purchase|order|abandon|query|advert|audience|targeting|segment|alexa|converse|rufus|assistant|voice|whisper|device|browser" | head -30

else
  echo "ERROR: '$TARGET' is not a .zip file or directory."
  exit 1
fi

echo ""
echo "====================================================="
echo " Inspection complete. No files were modified."
echo "====================================================="
