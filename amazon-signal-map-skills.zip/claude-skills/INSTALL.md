# Installing the Amazon Signal Map Skills

Two Claude Code skills that turn a raw Amazon data export into structured seller-intelligence reports.

---

## What You're Installing

| Skill | Trigger | Job |
|---|---|---|
| `amazon-data-export-intelligence` | You have an Amazon export archive | Unpack, inventory, analyze → 10 intelligence artifacts |
| `seller-intelligence-packager` | Analysis is done, you want a deck or playbook | Package artifacts → presentation or operator playbook |

---

## Prerequisites

- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) installed
- macOS or Linux (scripts use bash)
- Python 3 installed (for `scripts/sample-csv.sh` JSON parsing — optional but recommended)

---

## Installation

### Option A — Install to Personal Skills Folder (Recommended)

Copies skills to `~/.claude/skills/` where Claude Code picks them up automatically.

```bash
# From the project root
cp -r claude-skills/amazon-data-export-intelligence ~/.claude/skills/
cp -r claude-skills/seller-intelligence-packager ~/.claude/skills/

# Verify
ls ~/.claude/skills/ | grep -E "amazon|seller"
```

### Option B — Use from Project Folder Directly

If you want skills scoped to this project only, place a `CLAUDE.md` that tells Claude where to find them. The `claude-skills/CLAUDE.md` in this repo already serves this purpose when working inside the `claude-skills/` directory.

### Option C — Manual Prompt Path (No Installation)

If you prefer to paste prompts directly rather than using skills, use `PROMPT_VAULT.md`:
- Prompt 1 = Phase 1–2 of `amazon-data-export-intelligence`
- Prompt 2 = Phase 3–6 of `amazon-data-export-intelligence`

---

## Using the Scripts

The `scripts/` folder contains two inspection utilities. These run locally and never modify source files.

```bash
# Make executable (one-time)
chmod +x claude-skills/scripts/inspect-archive.sh
chmod +x claude-skills/scripts/sample-csv.sh

# Inspect a ZIP archive (shows structure without extracting)
./claude-skills/scripts/inspect-archive.sh ~/Desktop/your-amazon-export.zip

# Inspect an extracted folder
./claude-skills/scripts/inspect-archive.sh ~/Desktop/amazon-export-folder/

# Sample a large CSV file (shows headers + first 5 rows)
./claude-skills/scripts/sample-csv.sh ~/Desktop/amazon-export/Search.SearchEngagement.csv

# Sample 10 rows from a JSON file
./claude-skills/scripts/sample-csv.sh ~/Desktop/amazon-export/Advertising.ConversionEvents.json 10
```

---

## Invoking Skills in Claude Code

```
# Start the export analysis workflow
/amazon-data-export-intelligence

# Package completed analysis into a deck or playbook
/seller-intelligence-packager
```

Or use natural language — Claude will invoke the skill automatically if the description matches your request.

---

## File Reference

| File | Purpose |
|---|---|
| `claude-skills/amazon-data-export-intelligence/SKILL.md` | Primary analysis skill |
| `claude-skills/seller-intelligence-packager/SKILL.md` | Packaging/output skill |
| `claude-skills/CLAUDE.md` | Workspace configuration for Claude Code |
| `claude-skills/amazon-export-field-reference.md` | Known Amazon export fields and their meaning |
| `claude-skills/scripts/inspect-archive.sh` | Safe archive inspection script |
| `claude-skills/scripts/sample-csv.sh` | Large file sampling script |
| `claude-skills/INSTALL.md` | This file |
| `claude-skills/EVAL.md` | Eval cases to verify skills work correctly |
| `PROMPT_VAULT.md` | Manual-path prompts (no skill invocation needed) |
| `OPERATOR_GUIDE.md` | End-to-end workflow guide for operators |

---

## Troubleshooting

**Skills not showing up in Claude Code:**
```bash
ls ~/.claude/skills/amazon-data-export-intelligence/SKILL.md
# If missing, re-run the cp command from Option A
```

**Script permission denied:**
```bash
chmod +x claude-skills/scripts/*.sh
```

**Python3 not found (JSON sampling falls back to raw text):**
Install Python 3 or use the CSV variant of `sample-csv.sh` — CSV inspection does not require Python.

**Archive extraction fails (bad zip / encoding issues):**
Claude will document these in `ANALYSIS_LOG.md` and continue with what can be extracted. Check the log for details.
